#include <stdio.h>

int main() {
    int quantidade_macas;
    float custo_total;
    const float PRECO_ACIMA_DUZIA = 1.95; 
    const float PRECO_ABAIXO_DUZIA = 2.30; 
    const int DUZIA = 12;

    // Solicite e leia a quantidade de maçãs compradas
    printf("Digite o número de maçãs compradas: ");
    scanf("%d", &quantidade_macas);

    // Verifique se a quantidade é uma dúzia (12) ou acima (>=12)
    if (quantidade_macas >= DUZIA) {
        custo_total = quantidade_macas * PRECO_ACIMA_DUZIA;
    }

    // Se não for 12 ou mais, a quantidade é menor que uma dúzia (< 12)
    else {
        custo_total = quantidade_macas * PRECO_ABAIXO_DUZIA;
    }

    // 3. Exiba o resultado
    printf("\nO número de maçãs compradas foi: %d\n", quantidade_macas);
    printf("O custo total da compra é: R$ %.2f\n", custo_total);

    return 0;
}
#include <stdio.h>
int main() {
    float numero;
    // solicite um número ao usuário
    printf("Digite um número: ");

    // Leia o número ao usuário
    scanf("%f", &numero);

    // Verifica se o número é positivo, negativo ou zero
    if (numero > 0) {
        printf("O número %.2f é positivo.\n", numero);
    } else if (numero < 0) {
        printf("O número %.2f é negativo.\n", numero);
    } else {
        printf("O número é zero.\n");
    }

    return 0;
}